#include "StdAfx.h"
#include "fiboo.h"


fiboo::fiboo(void)
{
	vec[N]=0;
	tamano=0;
}
void fiboo::setvec(int e, int pos)
{vec[pos]=e;
}
	int fiboo::getvec(int pos)
	{return vec[pos];}
	void fiboo::settam(int e)
	{tamano=e;}
	int fiboo::gettam()
	{return tamano;}
	void fiboo::calcular(int tam)
	{int i;
	vec[0]=0;
	vec[1]=1;
	
	for(i=2;i<tam;i++)
	{vec[i]=vec[i-1]+vec[i-2];}
	}