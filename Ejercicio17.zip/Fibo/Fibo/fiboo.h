#pragma once
#include <iostream>
#define N 100

class fiboo
{
private: 
	int tamano;
	int vec[N];
public:
	fiboo(void);
	void setvec(int e, int pos);
	int getvec(int pos);
	void settam(int e);
	int gettam();
	void calcular(int tam);
};

